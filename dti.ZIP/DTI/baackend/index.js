const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json()); // Middleware to parse JSON data

// Connect to MongoDB
mongoose.connect("mongodb://127.0.0.1:27017/quickwash", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Order Schema & Model
const orderSchema = new mongoose.Schema({
  customerName: String,
  details: String,
  status: { type: String, default: "Pending" },
});

const Order = mongoose.model("Order", orderSchema);

// API Route: Get All Orders
app.get("/api/orders", async (req, res) => {
  const orders = await Order.find();
  res.json(orders);
});

// API Route: Add New Order
app.post("/api/orders", async (req, res) => {
  const { customerName, details } = req.body;
  const newOrder = new Order({ customerName, details });
  await newOrder.save();
  res.status(201).json({ message: "Order placed successfully!", order: newOrder });
});

app.listen(5000, () => console.log("Server running on port 5000"));
