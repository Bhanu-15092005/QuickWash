import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

const App = () => {
  const [userType, setUserType] = useState(null);
  const [orders, setOrders] = useState([]);
  const [customerName, setCustomerName] = useState("");
  const [details, setDetails] = useState("");
  const [activePage, setActivePage] = useState("home"); // Active tab

  // Fetch orders when customer logs in
  useEffect(() => {
    if (userType === "customer") {
      axios.get("http://localhost:5000/api/orders")
        .then((response) => setOrders(response.data))
        .catch((error) => console.error("Error fetching orders:", error));
    }
  }, [userType]);

  // Function to place an order
  const handleOrderSubmit = async (e) => {
    e.preventDefault();
    if (!customerName || !details) return;

    try {
      const response = await axios.post("http://localhost:5000/api/orders", {
        customerName,
        details,
      });

      setOrders([...orders, response.data.order]); // Update state
      setCustomerName(""); // Clear fields
      setDetails("");
    } catch (error) {
      console.error("Error placing order:", error);
    }
  };

  return (
    <div className="app-container">
      {/* Navbar */}
      <nav className="navbar">
        <a onClick={() => setActivePage("home")}>Home</a>
        {userType && <a onClick={() => setActivePage("manageOrders")}>Manage Orders</a>}
        <a onClick={() => setActivePage("contact")}>Contact Us</a>
        <a onClick={() => setActivePage("about")}>About Us</a>
        {userType === "customer" && <a onClick={() => setActivePage("status")}>Status</a>}
      </nav>

      {/* Selection Popup */}
      {!userType && (
        <div className="popup-overlay">
          <div className="popup">
            <h1>Welcome to Quickwash</h1>
            <p>Are you a customer or staff?</p>
            <div className="selection-buttons">
              <button onClick={() => setUserType("customer")} className="customer">Customer</button>
              <button onClick={() => setUserType("staff")} className="staff">Staff</button>
            </div>
          </div>
        </div>
      )}

      {/* Dynamic Content Section */}
      <div className={`content ${userType ? "show" : ""}`}>
        {activePage === "home" && (
          <div className="home">
            <h2>Welcome to Quickwash</h2>
            <p>We provide top-notch laundry services with fast and reliable cleaning.</p>
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkdzkjtq-bQtYA-q6FzygmdhQ6ekLIhmSBPw&s" alt="Laundry" />
          </div>
        )}

        {activePage === "manageOrders" && userType === "customer" && (
          <div>
            <h2>Track Your Order</h2>
            <form onSubmit={handleOrderSubmit} className="order-form">
              <input
                type="text"
                placeholder="Your Name"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                required
              />
              <input
                type="text"
                placeholder="Order Details"
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                required
              />
              <button type="submit">Place Order</button>
            </form>

            <h3>Your Orders</h3>
            <ul className="order-list">
              {orders.map((order) => (
                <li key={order._id}>
                  <strong>{order.customerName}</strong>: {order.details} - 
                  <span className={`status ${order.status.toLowerCase()}`}>{order.status}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {activePage === "contact" && (
          <div className="contact">
            <h2>Contact Us</h2>
            <p>Email: support@quickwash.com</p>
            <p>Phone: +1 234 567 890</p>
            <p>Visit us at: 123 Quickwash St, CleanCity</p>
          </div>
        )}

        {activePage === "about" && (
          <div className="about">
            <h2>About Quickwash</h2>
            <p>We believe in quality cleaning with the fastest service in town.</p>
            <p>Established in 2025, Quickwash has served thousands of happy customers.</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer>
        <p>© 2025 Quickwash. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;
